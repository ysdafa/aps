﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define MAX 200

typedef struct RECT
{
	int y;
	int x;
	int size;
}RECT;

RECT queue[MAX*MAX*MAX] = { 0 };//队列记录一个点的坐标和其矩形的大小
int front = 0, rear = 0;
int map[MAX + 1][MAX + 1] = { 0 };//保存每个点的大小
int coverMap[MAX + 1][MAX + 1] = { 0 };//标记黄色点的位置
bool visitMap[MAX + 1][MAX + 1] = { 0 };//标记是否使用过该点进行矩形覆盖

int check(int count)
{
	int coverCount = 0;
	while (rear >= 0)
	{
		RECT rect = queue[--rear];
		if (visitMap[rect.y][rect.x])continue;//相同的点，size大的覆盖过即可，无需重复覆盖
		else visitMap[rect.y][rect.x] = true;
		for (int i = rect.y; i < rect.y + rect.size; i++)
			for (int j = rect.x; j < rect.x + rect.size; j++)
			{
				if (coverMap[i][j])
				{
					coverMap[i][j] = 0;
					coverCount++;//覆盖的黄色点个数+1
					if (coverCount == count)
					{//如果全部覆盖完成，则返回，当前使用的矩形大小即为最小矩形大小
						return rect.size;
					}
				}
			}
	}

	return 1;
}

int main()
{
	freopen("input.txt", "r", stdin);
	int t = 0;
	scanf("%d\n", &t);
	for (int test = 1; test <= t; test++)
	{
		int yellowCnt = 0, w = 0, h = 0;
		front = 0, rear = 0;
		scanf("%d %d\n", &h, &w);
		for (int i = 0; i < h; i++)
		{
			for (int j = 0; j < w; j++)
			{
				visitMap[i][j] = 0;
				char a = 0;
				scanf("%c", &a);
				if (a == 'w')map[i][j] = 0;
				else
				{
					if (a == 'y')
					{
						yellowCnt++;//记录下黄色点的个数
						coverMap[i][j] = 1;
					}
					map[i][j] = 1;
					RECT rect = { i, j, 1 };
					queue[rear++] = rect;//将点加入队列
				}
			}
			scanf("\n");
		}

		while (front != rear)
		{
			RECT rect = queue[front++];
			if ((map[rect.y + 1][rect.x] >= rect.size)
				&& (map[rect.y][rect.x + 1] >= rect.size)
				&& (map[rect.y + 1][rect.x + 1] >= rect.size))
			{
				map[rect.y][rect.x] = ++rect.size;//如果size值能够更大，则重新加入队列
				queue[rear++] = rect;
			}
		}

		printf("%d\n", check(yellowCnt));
	}

	return 0;
}