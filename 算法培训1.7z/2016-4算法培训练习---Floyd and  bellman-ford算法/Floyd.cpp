#include <stdio.h>
#define MAX 6
#define MAX_VALUE 65536

int v[MAX + 1][MAX + 1] = { 0 };
int p[MAX + 1][MAX + 1] = { 0 };
void Floyd()
{
	v[1][1] = 0;
	for (int k = 1; k <= MAX; k++)
	for (int i = 1; i <= MAX; i++)
	for (int j = 1; j <= MAX; j++)
		if (v[i][k] + v[k][j]<v[i][j])
		{
			v[i][j] = v[i][k] + v[k][j];
			p[i][j] = k;
		}
}

void initV(void)
{
	for (int i = 1; i <= MAX; i++)
		for (int j = 1; j <= MAX; j++)
		{
			v[i][j] = MAX_VALUE;
		}
}
void printPathFloyd()
{
	printf("%d\n", v[1][6]);
	int path[10];
	int end = 0;
	int curValue = 6;
	while (curValue != 0)
	{
		path[end++] = curValue;
		curValue = p[1][curValue];
	}
	for (int j = end - 1; j >= 0; j--)
	{
		printf("%d ", path[j]);
	}
	printf("\n");
}

int main(int argc, char** argv)
{
	freopen("input.txt", "r", stdin);
	int N;
	scanf("%d\n", &N);

	for (int case_num = 0; case_num < N; case_num++)
	{
		initV();
		int line_num;
		scanf("%d\n", &line_num);
		for (int i = 0; i < line_num; i++)
		{
			int pt1, pt2, length;
			scanf("%d %d %d", &pt1, &pt2, &length);
			v[pt1][pt2] = length;
			v[pt2][pt1] = length;
		}
		Floyd();
		printPathFloyd();
	}
}
