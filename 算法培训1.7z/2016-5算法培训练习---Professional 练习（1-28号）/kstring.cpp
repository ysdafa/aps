////K-th sub string  

#include <iostream>
using namespace std;

int strCompare(char *src, char *dst)
{
	while (*src)
	{
		if (*src != *dst) break;
		src++;
		dst++;
	}

	return (*src - *dst);
}

char input[1000];
int su[1000];
int lcp[1000];

int main(void)
{
	int T;
	int i_th;
	int slen;

	freopen("input.txt", "r", stdin);

	cin >> T;

	for (int tc = 1; tc <= T; ++tc)
	{
		cin >> i_th >> input;

		slen = 0;

		while (input[slen])
		{
			slen++;

			su[slen] = slen;
			lcp[slen] = 0;
		}

		for (int i = 1; i <= slen; i++)
		{
			int min = i, t;
			for (int j = i; j <= slen; j++)
			{
				t = strCompare(input + su[min] - 1, input + su[j] - 1);

				if (t > 0) min = j;
			}

			if (min != i)
			{
				t = su[min];
				su[min] = su[i];
				su[i] = t;
			}
		}

		for (int i = 2; i <= slen; i++)
		{
			int j = su[i] - 1;
			int k = su[i - 1] - 1;

			while (input[j] == input[k])
			{
				lcp[i]++;

				j++;
				k++;
			}
		}

		int i = 1;
		while (i_th > 0 && i <= slen)
		{
			i_th = i_th - (slen - su[i] + 1 - lcp[i]);
			i++;
		}



		cout << "#" << tc << " ";
		if (i_th <= 0)
		{
			int len = slen - su[i - 1] + 1 + i_th;
			for (int j = 0; j < len; j++)
				cout << input[su[i - 1] - 1 + j];
		}
		else
		{
			cout << "none";
		}

		cout << endl;
	}
	return 0;
}