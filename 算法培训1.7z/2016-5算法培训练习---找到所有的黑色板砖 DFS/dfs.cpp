#include <iostream>
using namespace std;
#define MAXD	21
int Answer = -1;
int V;
int H;
char data[MAXD][MAXD];
int visited[MAXD][MAXD];
int offsetX[4] = {-1,1,0,0};
int offsetY[4] = { 0, 0, -1, 1 };

int dfs(int currX, int currY)
{
	if (data[currX][currY] == '#') {
		return 0;
	}
	Answer++;
	for (int i = 0; i < 4; i++) {
		int startX = currX + offsetX[i];
		int startY = currY + offsetY[i];
		if (startX >= 0 && startX < H && startY >= 0 && startY < V && !visited[startX][startY]) {
			visited[startX][startY] = 1;
			dfs(startX, startY);
		}
	}
	return 0;
}

int main(int argc, char** argv) {
	int T = 0;
	//freopen("input.txt", "r", stdin);
	cin >> T;
	for (int test_case = 0; test_case < T; test_case++) {
		Answer = 0;
		cin >> V;
		cin >> H;
		int startX=0;
		int startY=0;
		for (int i = 0; i < H; i++) {
			for (int j = 0; j < V; j++) {
				cin >> data[i][j];
				visited[i][j] = 0;
				if (data[i][j] == '@') {
					startX = i;
					startY = j;
				}
			}
			cin.get();
		}
		visited[startX][startY] = 1;
		dfs(startX, startY);
		cout << "Case #" << test_case + 1 << endl;
		cout << Answer << endl;
		
	}
	

	return 0;
}