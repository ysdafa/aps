#include<iostream>
#include<algorithm>
using namespace std;

const static int MAX = 22;
int W, H;
int map[MAX][MAX];
int startx, starty;
int visited[MAX][MAX];

int coutnumber = 0;

int queue[MAX*MAX][2];

int direct[4][2] = { { 1, 0 }, { -1, 0 }, { 0, 1 }, {0,-1} };

void Init(void)
{
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			map[i][j] = -1;
			visited[i][j] = 0;
		}
	}

	for (int i = 0; i < MAX*MAX; i++)
	{
		queue[i][0] = 0;
		queue[i][1] = 0;
	}
	coutnumber = 0;
}

int BFS(int sx,int sy)
{
	int front = 0;
	int	rear = 0;
	int tmp_x = 0;
	int tmp_y = 0;
	int next_x = 0;
	int next_y = 0;

	visited[sy][sx] = 1;	
	queue[front][0] = sx;
	queue[front++][1] = sy;

	coutnumber = 1;

	while (front != rear)
	{
		tmp_x = queue[rear][0];
		tmp_y = queue[rear++][1];

		for (int i = 0; i < 4; i++)
		{
			next_x = tmp_x + direct[i][0];
			next_y = tmp_y + direct[i][1];
			if (next_x>=1 && next_x<=W && next_y >=1 && next_y <= H 
				&& visited[next_y][next_x] != 1
				&& map[next_y][next_x] == 1) //add condition
			{
				queue[front][0] = next_x;
				queue[front++][1] = next_y;
				visited[next_y][next_x] = 1;
				coutnumber++;
			}
		}
	}

	return 1;
}

int DFS(int sx, int sy)
{	
	int next_x = 0;
	int next_y = 0;	

	coutnumber++;

	for (int i = 0; i < 4; i++)
	{
		next_x = sx + direct[i][0];
		next_y = sy + direct[i][1];
		if (next_x >= 1 && next_x <= W && next_y >= 1 && next_y <= H
			&& visited[next_y][next_x] != 1
			&& map[next_y][next_x] == 1) //add condition
		{			
			visited[next_y][next_x] = 1;			
			DFS(next_x, next_y);
			//visited[next_y][next_x] = 0;
		}
	}

	return 1;
}

int main()
{
	//	freopen("input_ZOJ1709.txt", "r", stdin);
	setbuf(stdout, NULL);
	int T = 0;
	cin >> T;
	for (int testcase = 1; testcase <= T; testcase++)
	{
		Init();
		cin >> W >> H;

		for (int i = 1; i <= H; i++)
		{
			for (int j = 1; j <= W; j++)
			{
				char cstr;
				cin >> cstr;
				if (cstr == '.')
				{
					map[i][j] = 1;
				}
				else if (cstr == '#')
				{
					map[i][j] = 0;
				}
				else
				{
					map[i][j] = 1;
					startx = j;
					starty = i;
				}
			}
		}

		//BFS(startx, starty);
		visited[starty][startx] = 1;
		DFS(startx, starty);

		cout << coutnumber << endl;

	}

	
	

	return 0;
}