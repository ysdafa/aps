#include<iostream>
using namespace std;

const static int NODEMAX = 50;
int N, M;
int visited[NODEMAX];
int map[NODEMAX][NODEMAX];
int NodeFee[NODEMAX];
int sepoint[NODEMAX][2];

int path[NODEMAX];
int stack[NODEMAX];	  

typedef struct _Nodeinfo
{
	int id;
	int distance;
	int visited;
	int parent;
}Nodeinfo;

Nodeinfo DisMap[NODEMAX];

Nodeinfo queue[NODEMAX*NODEMAX];

void Init()
{
	for (int i = 0; i < NODEMAX; i++)
	{
		for (int j = 0; j < NODEMAX; j++)
		{
			map[i][j] = 0;	   			
		}
	}

	for (int i = 0; i < NODEMAX; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			sepoint[i][j] = 0;
		}
	}

	for (int i = 0; i < NODEMAX; i++)
	{
		NodeFee[i] = 0;
		visited[i] = 0;
		stack[i] = 0;
		DisMap[i].id = i;
		DisMap[i].distance = 10000;
		DisMap[i].visited = 0;
		DisMap[i].parent = 0;
		path[i] = 0;
	}		
}

int InsertQueue(Nodeinfo item,int index)
{
	int i;
	for (i = 0; i < index; i++)
	{
		if (item.distance >= queue[i].distance)
		{
			break;
		}
	}
		
	for (int j = index; j >= i;j--)
	{
		queue[j + 1] = queue[j];
	}

	queue[i] = item;
	return ++index;

}

void Dijsktra(int node)
{
	int index = 0;
	Nodeinfo tmp_node;
	Nodeinfo next_node;
	Nodeinfo first;
	first.distance = 0;
	first.id = node;
	first.visited = 0;
	first.parent = 0;

	queue[index++] = first;
	DisMap[first.id] = first;  	

	while (index != 0)
	{
		tmp_node = queue[--index];
		if (DisMap[tmp_node.id].visited == 1) continue;
		DisMap[tmp_node.id].visited = 1;

		for (int i = 1; i <= N;i++)
		{
			if (map[tmp_node.id][i] <= 0) continue;
			if (DisMap[i].visited == 1) continue;
			if (DisMap[i].distance > DisMap[tmp_node.id].distance + map[tmp_node.id][i] + NodeFee[i])
			{
				DisMap[i].distance = DisMap[tmp_node.id].distance + map[tmp_node.id][i] + NodeFee[i];
				next_node.id = i;
				next_node.distance = DisMap[i].distance;
				index = InsertQueue(next_node, index);
				DisMap[i].parent = tmp_node.id;
				//path[tmp_node.id] = i;
			}
			else if ((DisMap[i].distance == DisMap[tmp_node.id].distance + map[tmp_node.id][i] + NodeFee[i]) && DisMap[tmp_node.id].parent < DisMap[i].parent)
			{
				DisMap[i].parent = DisMap[tmp_node.id].parent;
			}
		}
	}	   

}

int main()
{
	//	freopen("input_ZOJ1709.txt", "r", stdin);
	setbuf(stdout, NULL);
	int T = 0;
	cin >> T;
	for (int testcase = 1; testcase <= T; testcase++)
	{
		Init();
		cin >> N;
		for (int i = 1; i <= N; i++)
		{
			for (int j = 1; j <= N; j++)
			{
				cin >> map[i][j];
			}
		}

		for (int i = 1; i <= N; i++)
		{
			cin >> NodeFee[i];
		}

		int sNode, eNode;
		int k = 1;
		cin >> sNode >> eNode;
		while (sNode != -1)
		{
			sepoint[k][0] = sNode;
			sepoint[k++][1] = eNode;
			cin >> sNode >> eNode;
		}

		for (int i = 1; i <= N; i++)
		{
			if (sepoint[i][0] == 0) break;
			Dijsktra(sepoint[i][0]);
			cout << "Path: ";
						
			int cur = sepoint[i][1];
			int step = 0;
			do
			{
				path[step++] = cur;
				cur = DisMap[cur].parent;

			} while (cur != 0);
			for (int mm = step - 1; mm >= 0; mm--)
			{
				cout << path[mm] << " ";
			}

			cout << endl;
			cout << "Total cost: ";
			cout << DisMap[i].distance - NodeFee[sepoint[i][1]] << endl;
			for (int k = 0; k < NODEMAX; k++)
			{  				
				path[k] = 0;
				visited[k] = 0;
				stack[k] = 0;
				DisMap[k].id = k;
				DisMap[k].distance = 10000;
				DisMap[k].visited = 0;
				DisMap[k].parent = 0;
			}
			
		}




	}

	return 0;
}