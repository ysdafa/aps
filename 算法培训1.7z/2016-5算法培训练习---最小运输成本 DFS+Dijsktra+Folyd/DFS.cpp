#include<iostream>
using namespace std;

const static int NODEMAX = 50;
int N, M;
int visited[NODEMAX];
int map[NODEMAX][NODEMAX];
int NodeFee[NODEMAX];

int sepoint[NODEMAX][2];

int path[NODEMAX];
int stack[NODEMAX];
int cur = 0;


int answer;


void Init()
{
	for (int i = 0; i < NODEMAX; i++)
	{
		for (int j = 0; j < NODEMAX; j++)
		{
			map[i][j] = 0;			
		}
	}

	for (int i = 0; i < NODEMAX; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			sepoint[i][j] = 0;			
		}		
	}

	for (int i = 0; i < NODEMAX; i++)
	{
		NodeFee[i] = 0;		
		visited[i] = 0;
		stack[i] = 0;
		path[i] = 0;
	}

	answer = 10000;
	cur = 0;	
}

int DFS(int sNode,int eNode,int distance)
{
	if (sNode == eNode)
	{
		if (answer > distance)
		{
			answer = distance;

			for (int i = 0; i < cur; i++)
			{
				path[i] = stack[i];
			}
		}
		else if (answer == distance)
		{			
			int update = 0;
			for (int i = 0; i < cur; i++)
			{
				if (path[i] > stack[i])
				{
					update = 1;
					break;
				}
				else if (path[i] < stack[i])
				{
					update = 2;
					break;
				}
			}

			if (update == 1)
			{
				for (int i = 0; i < NODEMAX; i++)
				{
					path[i] = 0;
				}
				for (int i = 0; i < cur; i++)
				{
					path[i] = stack[i];
				}
			}
		}
				
		return 1;
	}	
	if (answer < distance) return 1;	
	
	for (int i = 1; i <= N;i++)
	{
		if (map[sNode][i] > 0 && visited[i] == 0)
		{
			visited[i] = 1;		
			stack[cur++] = i;
			DFS(i, eNode, distance + NodeFee[i] + map[sNode][i]);
			visited[i] = 0;
			stack[--cur] = 0;
		}
	}
}

int main()
{
	//	freopen("input_ZOJ1709.txt", "r", stdin);
	setbuf(stdout, NULL);
	int T = 0;
	cin >> T;
	for (int testcase = 1; testcase <= T; testcase++)
	{
		Init();
		cin >> N;
		for (int i = 1; i <= N; i++)
		{
			for (int j = 1; j <= N; j++)
			{
				cin >> map[i][j];
			}
		}

		for (int i = 1; i <= N; i++)
		{
			cin >> NodeFee[i];
		}

		int sNode, eNode;
		int k = 1;
		cin >> sNode >> eNode;
		while (sNode != -1)
		{
			sepoint[k][0] = sNode;
			sepoint[k++][1] = eNode;
			cin >> sNode >> eNode;
		}

		for (int i = 1; i <= N; i++)
		{
			visited[sepoint[i][0]] = 1;
			stack[cur++] = sepoint[i][0];
			DFS(sepoint[i][0], sepoint[i][1], 0);
			cout << "Path: ";
			for (int i = 0; i < NODEMAX; i++)
			{
				if (path[i] == 0) break;
				cout << path[i] << " ";
			}
			cout << endl;
			cout << "Total cost: ";
			cout << answer - NodeFee[sepoint[i][1]] << endl;
			for (int i = 0; i < NODEMAX; i++)
			{			
				path[i] = 0;
				visited[i] = 0;
				stack[i] = 0;
			}
			answer = 10000;
			cur = 0;			
		}

		

		
	}

	return 0;
}