#include <stdio.h>

#define MAX 6
#define MAX_VALUE 65536

typedef struct Node
{
	int id;      //�ڵ�id
	int distance;  //��c1�ľ���
	bool visited;//�õ��Ƿ񱻷���
	int parent;  // ���ڵ�
}Node;

int v[MAX + 1][MAX + 1] = { 0 };//���ӱ�
Node q[100]; //��������
int cur = 0; //βָ��
Node pts[MAX + 1];//���ÿ����״̬

void insert(Node it)
{
	int i = 0;
	for (i = 0; i < cur; i++)
	{
		if (it.distance > q[i].distance)
		{
			break;
		}
	}
	for (int j = cur - 1; j >= i; j--)
	{
		q[j + 1] = q[j];
	}
	q[i] = it;
	cur++;
}

void Dijkstra(int s)
{
	for (int i = 1; i <= MAX; i++)
	{
		pts[i].id = i;
		pts[i].distance = MAX_VALUE;
		pts[i].visited = false;
		pts[i].parent = 0;
	}

	pts[s].distance = 0;
	q[cur++] = pts[s];
	while (cur!=0)
	{
		cur--;
		Node c = q[cur];
		if (pts[c.id].visited)continue;
		pts[c.id].visited = true;
		for (int i = 1; i <= MAX; i++)
		{
			if (i == c.id)continue;
			if (pts[i].visited)continue;
			if (v[c.id][i] == MAX_VALUE)continue;
			if (pts[i].distance > pts[c.id].distance + v[c.id][i])
			{
				pts[i].distance = pts[c.id].distance + v[c.id][i];
				pts[i].parent = c.id;
				insert(pts[i]);
			}
		}
	}
}

void initV(void)
{
	for (int i = 1; i <= MAX; i++)
		for (int j = 1; j <= MAX; j++)
		{
			v[i][j] = MAX_VALUE;
		}
}
int a[10] = { 5, 3, 9, 8, 1, 2, 7, 6, 4, 0 };

void qsort(int begin, int end)
{
	if (begin >= end)return;

	int left = begin;
	int right = end;
	int key = a[left];
	while (left < right)
	{
		while ((left < right) && (a[right] <= key))right--;
		a[left] = a[right];
		while ((left < right) && (a[left] >= key))left++;
		a[right] = a[left];
	}
	a[left] = key;
	qsort(begin, left-1);
	qsort(left+1, end);
}


void printPathDijkstra()
{
	for (int i = 1; i <= MAX; i++)
	{
		printf("%d %d\n", pts[i].id, pts[i].distance);
	}
	for (int i = 1; i <= MAX; i++)
	{
		int path[MAX] = {0};
		int step = 0;
		int cur = i;
		do
		{
			path[step++] = cur;
			cur = pts[cur].parent;
		} while (cur != 0);
		for (int j = step - 1; j >= 0; j--)
		{
			printf("%d ", path[j]);
		}
		printf("\n");
	}
}

int main(int argc, char** argv)
{
	freopen("input.txt", "r", stdin);
	int N;
	scanf("%d\n", &N);

	qsort(0, 9);
	for (int case_num = 0; case_num < N; case_num++)
	{
		initV();
		int line_num;
		scanf("%d\n", &line_num);
		for (int i = 0; i < line_num; i++)
		{
			int pt1, pt2, distance;
			scanf("%d %d %d", &pt1, &pt2, &distance);
			v[pt1][pt2] = distance;
			v[pt2][pt1] = distance;
		}
		 Dijkstra(1);
		 printPathDijkstra();
	}
}

