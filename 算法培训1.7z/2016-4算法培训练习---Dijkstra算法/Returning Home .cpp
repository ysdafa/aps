#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define MAX 1001

int map[MAX][MAX] = {0};
int stack[MAX*MAX][2] = {0};
bool visit[MAX] = { 0 };
int minDis[MAX] = {0};

int insert(int index, int cnt)
{
	int i = 0;
	for (i = 0; i < cnt; i++)
	{
		if (minDis[index] > stack[i][1])break;
	}
	for (int j = cnt; j > i; j--)
	{
		stack[j][0] = stack[j - 1][0];
		stack[j][1] = stack[j - 1][1];
	}
	stack[i][0] = index;
	stack[i][1] = minDis[index];
	return cnt + 1;
}

int Dijkstra(int max)
{
	for (int i = 1; i <= max; i++)
	{
		minDis[i] = MAX*MAX*100;
		visit[i] = false;
	}

	int cur = 0;
	stack[cur][0] = 1;
	stack[cur++][1] = 0;
	minDis[1] = 0;
	while (cur != 0)
	{
		int pt = stack[--cur][0];
		if (visit[pt] == true)continue;
		visit[pt] = true;
		for (int i = 1; i <= max; i++)
		{
			if ((visit[i] == true)||(map[pt][i] == 0))continue;
			if (minDis[i] > minDis[pt] + map[pt][i])
			{
				minDis[i] = minDis[pt] + map[pt][i];
				cur = insert(i, cur);
			}
		}
	}

	return minDis[max];
}

int main()
{
	freopen("input.txt", "r", stdin);
	int t = 0;
	scanf("%d\n", &t);
	for (int test = 1; test <= t; test++)
	{
		int edge, pt;
		scanf("%d %d\n", &edge, &pt);
		for (int i = 0; i < edge; i++)
		{
			int start, end, value;
			scanf("%d %d %d\n", &start, &end, &value);
			if (map[start][end] == 0)
			{
				map[end][start] = map[start][end] = value;
			}
			else
			{
				map[end][start] = map[start][end] 
								= (map[start][end] < value) ? map[start][end] : value;
			}
		}

		printf("%d\n", Dijkstra(pt));
		for (int i = 1; i <= pt; i++)
			for (int j = 1; j <= pt; j++)map[i][j] = 0;
	}
}