#include<iostream>

using namespace std;

const static int SIZE = 10;
int N;
int Data[SIZE];


void QsortData(int front, int end, int Array[])
{
	if (front >= end) return;
	int left = front;
	int right = end;
	int A0 = Array[right];

	while (left < right)
	{
		//while (left < right && Array[left] <= A0) //����
		while (left < right && Array[left] >= A0) //����
			left++;
		Array[right] = Array[left];
		//while (left < right && Array[right] >= A0) //����
		while (left < right && Array[right] <= A0) //����
			right--;
		Array[left] = Array[right];		
	}

	Array[left] = A0;
	QsortData(1,left-1,Array);
	QsortData(left+1,end,Array);
	return;
}

int main(int argc, char** argv)
{
	int test_case;
	int T = 0;

	/*
	The freopen function below opens input.txt in read only mode and
	sets your standard input to work with the opened file.
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/
#ifdef WIN32
	freopen("sample_input.txt", "r", stdin);
#endif
	cin >> T;
	for (test_case = 1; test_case <= T; ++test_case)
	{
		int Answer = 1;
		int cnt = 1;		
		cin >> N;
		for (int i = 1; i <= N;i++)
		{
			cin >> Data[i];
		}

		QsortData(1, N, Data);		

		cout << N;
	}

	return 0;//Your program should return 0 on normal termination.
}
