#include<iostream>

using namespace std;

int N; //nodes
int M; //edages
int W; //wormholes

const static int SIZE = 502;
const static int EDGE_SIZE = 2502;
const static int MAX = 10000;

//bellman-ford
int Dis[SIZE] = {0};
int nodenum = 0;
int edgenum = 0;

struct node
{
	int s;
	int e;
	int w;
}Edge[EDGE_SIZE];

void Init()
{
	for (int i = 0; i < SIZE;i++)
	{			
		Dis[i] = MAX;
	}

	for (int i = 0; i < EDGE_SIZE; i++)
	{
		Edge[i].s = 0;
		Edge[i].e = 0;
		Edge[i].w = 0;
	}
}


bool bellman_ford()
{
	for (int i = 1; i <= nodenum; i++)
	{
		Dis[i] = MAX;
	}
	Dis[1] = 0;
	bool Isok;
	for (int i = 1; i <= nodenum - 1; i++)
	{
		Isok = false;
		for (int j = 1; j <= edgenum; j++)
		{
			if (Dis[Edge[j].s] + Edge[j].w < Dis[Edge[j].e])
			{
				Dis[Edge[j].e] = Dis[Edge[j].s] + Edge[j].w;
				Isok = true;
			}				
		}
		if (false == Isok)
		{
			break;
		}
	}

	for (int j = 1; j <= edgenum; j++)
	{
		if (Dis[Edge[j].s] + Edge[j].w < Dis[Edge[j].e])
		{
			return true;
		}
	}

	return false;	
}


int main(int argc, char** argv)
{
	int test_case;
	int T = 0;
	
	/*
	The freopen function below opens input.txt in read only mode and
	sets your standard input to work with the opened file.
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/
#ifdef WIN32
	freopen("sample_input.txt", "r", stdin);
#endif
	cin >> T;
	for (test_case = 1; test_case <= T; ++test_case)
	{
		int Answer = 1;
		int cnt = 1;
		Init();
		cin >> N >> M >> W;
		nodenum = N;
		edgenum = 2 * M + W;
		for (int i = 1; i <= M; i++)
		{
			int node1 = 0;    
			int node2 = 0;
			int value = 0;			
			cin >> node1 >> node2 >> value;
			Edge[cnt].s = node1;
			Edge[cnt].e = node2;
			Edge[cnt++].w = value;
			Edge[cnt].e = node1;
			Edge[cnt].s = node2;
			Edge[cnt++].w = value;			
		}		

		for (int i = 1; i <= W; i++)
		{
			int node1 = 0;
			int node2 = 0;
			int value = 0;			
			cin >> node1 >> node2 >> value;
			Edge[cnt].s = node1;
			Edge[cnt].e = node2;
			Edge[cnt++].w = -value;			
		}

		//Floyd();
		if (bellman_ford())
		{
			cout << "YES" << endl;
		}
		else
		{
			cout << "NO" << endl;
		}			
	}

	return 0;//Your program should return 0 on normal termination.
}
