﻿#include<iostream>
#include<algorithm>
using namespace std;


void swap(int* a, int* b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

int partition(int arr[], int l, int r)
{
	int p = arr[l];
	int i = l, j = r;

	while(i <= j)
	{
		while( arr[i] >= p)
			if(++i == r)
				break;
		while( arr[j] <= p)
			if(--j == l)
				break;
		if(i < j)
			swap(arr+i, arr+j);
	}
	swap(arr+l, arr+j);
	return j;
}

void quicksort(int arr[], int low, int high)
{
	int pivot;

	if(low < high)
	{
		pivot = partition(arr, low, high);
		quicksort(arr, low, pivot-1);
		quicksort(arr, pivot+1, high);
	}
}

int n;  //木棒数量

bool dfs(int* stick,bool* visit,int len,int InitLen,int s,int num)  //len:当前正在组合的棒长  InitLen:目标棒长  
{                                                                  //s:stick[]的搜索起点  num:已用的棒子数量
    if(num==n)
        return true;

    for(int i=s;i<n;i++)
    {
        if(visit[i] || (i>0 && visit[i-1]==false && stick[i]==stick[i-1]))  //剪枝3,等长的木棒只搜索一次
            continue;

        visit[i]=true;
        if(len+stick[i]<InitLen)
        {
            //if(dfs(stick,visit,len+stick[i],InitLen,i,num+1))
			if(dfs(stick,visit,len+stick[i],InitLen,i+1,num+1))//i+1 -510ms
                return true;
        }
        else if(len+stick[i]==InitLen)
        {
            if(dfs(stick,visit,0,InitLen,0,num+1))
                return true;
				
			visit[i]=false;//pruning 5 尝试第i个木棒的第一段，假设stick[j]为当前可以被使用的最长的木棍，如果此次组合失败，直接退出搜索
			return false;
        }
        visit[i]=false;

        if(len==0)  //剪枝4，构建新棒时，对于新棒的第一根棒子，在搜索完所有棒子后都无法组合
            break;  //则说明该棒子无法在当前组合方式下组合，不用往下搜索(往下搜索会令该棒子被舍弃)，直接返回上一层
    }
    return false;
}

int main(void)
{
    while(cin>>n && n)
    {
        int* stick=new int[n];
        bool* visit=new bool[n];
        int sumlen=0;

        for(int i=0;i<n;i++)
        {
            cin>>stick[i];
            sumlen+=stick[i];
            visit[i]=false;
        }

        quicksort(stick,0,n-1);
        int maxlen=stick[0];   //最大的棒为InitLen的搜索起点

        bool flag=false;
                             //剪枝1,若能在[maxlen,sumlen-InitLen]找到最短的InitLen，该InitLen必也是[maxlen,sumlen]的最短
        //for(int InitLen=maxlen;InitLen<=sumlen-InitLen;InitLen++)  //InitLen:原始棒长
		for(int InitLen=maxlen;InitLen<=sumlen/2;InitLen++)  //InitLen:原始棒长, -40ms
        {   //剪枝2,InitLen必是sumlen的约数
            if(!(sumlen%InitLen) && dfs(stick,visit,0,InitLen,0,0))
            {
                cout<<InitLen<<endl;
                flag=true;
                break;
            }
        }
        if(!flag)
            cout<<sumlen<<endl;

        delete stick;
        delete visit;
    }
    return 0;
}