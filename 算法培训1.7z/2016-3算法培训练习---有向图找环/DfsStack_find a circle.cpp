#include<iostream>

using namespace std;

int N; //nodes
int M; //edages
const static int SIZE = 10;
int map[SIZE][SIZE];
//DFS
int stack[SIZE*SIZE];
int top = 0;

void Init()
{	
	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			map[i][j] = -1;
		}		
	}

	for (int i = 0; i < SIZE*SIZE; i++)
		stack[i] = 0;

	top = 0;
				
	return;
}

int findCyle(int node)
{
	for (int i = 0; i < top;i++)
	{
		if (node == stack[i])
		{
			return i;
		}
	}
	return -1;
}

int DFS(int test_case, int first)
{
	int index = findCyle(first);
	if (-1 != index)
	{
		cout << "# " << test_case<<endl;
		for (int i = index; i < top; i++)
		{
			cout << stack[i] << " ";
		}
		cout << endl;
		return 1;
	}
	
	int ret = 0;
	stack[top++] = first;
	
	for (int i = 1; i <= N; i++)
	{
		if (map[first][i] == 1)
		{			
			if (DFS(test_case, i) == 1) return 1;
		}
	}	
	stack[--top] = 0;
	return 0;
}



int main(int argc, char** argv)
{
	int test_case;
	int T = 0;
	int iHasCircle = 0;
	/*
	The freopen function below opens input.txt in read only mode and
	sets your standard input to work with the opened file.
	When you test your code with the sample data, you can use the function
	below to read in from the sample data file instead of the standard input.
	So. you can uncomment the following line for your local test. But you
	have to comment the following line when you submit for your scores.
	*/
#ifdef WIN32
	freopen("sample_input.txt", "r", stdin);
#endif

	cin >> T;

	for (test_case = 1; test_case <= T; ++test_case)
	{
		int i, j;		
		int node1, node2;
		int tmpnode;		
		int Answer = 0;
		Init();
		/*
		Read each test case from standard input.
		*/
		cin >> M;
		for (i = 1; i <= M; i++)
		{
			cin >> node1 >> node2;
			if (node1 > node2)
			{
				tmpnode = node1;
			}
			else
			{
				tmpnode = node2;
			}

			if (tmpnode >= N)
			{
				N = tmpnode;
			}
			map[node1][node2] = 1;						
		}

		for (i = 1; i <= N;i++)
		{
			for (j = 1; j <= N;j++)
			{
				if (map[i][j] == 1) 
				{
					Answer = DFS(test_case, i);
					if (Answer == 1) break;
				}
			}	
			if (Answer == 1) break;
		}
	
		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
		Please, implement your algorithm from this section.
		*/
		/////////////////////////////////////////////////////////////////////////////////////////////
		
		
		// Print the answer to standard output(screen). 		
		if (Answer == 0)
		{			
			cout << "# " << test_case<<endl;
			cout << Answer << endl;
		}
		
	}

	return 0;//Your program should return 0 on normal termination.
}
