#include <iostream>
//#include <cstdio>
using namespace std;
#define MAX_NUM 100

int DirectLine[MAX_NUM][2];// 0 is start point, 1 is end point
int loopStart;

bool visited[MAX_NUM];

bool dfs(bool *state, int lineNum, int curPoint, int level)
{

	int iLine;
	for (iLine = 0; iLine < lineNum; iLine++)
	{
		if (DirectLine[iLine][0] == curPoint)
		{
			int nextPoint = DirectLine[iLine][1];
			if (state[nextPoint])
			{
				loopStart = nextPoint;
				return true;
			}
			state[nextPoint] = true;
			//for (int i = 1; i <= 9; i++)
			//	printf("state %d ", state[i]);

				//printf("\n");
			if (dfs(state, lineNum, nextPoint, ++level))
				return true;
			else
				state[nextPoint] = false;
		}
	}
	visited[curPoint] = true;
	return false;
}

int main(int argc, char** argv)
{
	int T, test_case;
	int lineNum, iLine;
	int pointNum, iPoint;
	/*
	The freopen function below opens input.txt file in read only mode, and afterward,
	the program will read from input.txt file instead of standard(keyboard) input.
	To test your program, you may save input data in input.txt file,
	and use freopen function to read from the file when using cin function.
	You may remove the comment symbols(//) in the below statement and use it.
	Use #include<cstdio> or #include <stdio.h> to use the function in your program.
	But before submission, you must remove the freopen function or rewrite comment symbols(//).
	*/

	freopen("dfs.txt", "r", stdin);

	/*************init start**************/
	cin >> T;
	for (test_case = 0; test_case < T; test_case++)
	{

		pointNum = 0;
		cin >> lineNum;
		for (iLine = 0; iLine < lineNum; iLine++)
		{
			cin >> DirectLine[iLine][0];
			if (pointNum < DirectLine[iLine][0])
				pointNum = DirectLine[iLine][0];
			cin >> DirectLine[iLine][1];
			if (pointNum < DirectLine[iLine][1])
				pointNum = DirectLine[iLine][1];
		}

		for (iPoint = 1; iPoint <= pointNum; iPoint++)
		{
			visited[iPoint] = false;
		}
		loopStart = 0;
		bool state[MAX_NUM] = { false };
/*************init end**************/



/**************dfs start*****************/
		for (iPoint = 1; iPoint <= pointNum; iPoint++)
		{
			if (visited[iPoint])
				continue;
			int level = 0;
			state[iPoint] = true;
			if (dfs(state, lineNum, iPoint, level))
				break;
			else
			{
				state[iPoint] = false;
			}
		}

/****************dfs end***********************/

/*****************output start******************/
		cout << "Case #" << test_case + 1 << endl;
		cout << loopStart << " ";
		int curPoint = loopStart;
		int nextPoint = 0;
		if (!loopStart)
		{
			cout << endl;
			continue;
		}
		do
		{
			for (iLine = 0; iLine < lineNum; iLine++)
			{
				if (DirectLine[iLine][0] == curPoint)
				{
					nextPoint = DirectLine[iLine][1];
					if (nextPoint == loopStart)
						break;
					else if (state[nextPoint])
					{
						curPoint = nextPoint;
						cout << curPoint << " ";
					}
				}
			}
		} while (nextPoint != loopStart);
		cout << endl;
/*****************output start******************/

	}

	return 0;//Your program should return 0 on normal termination.
}