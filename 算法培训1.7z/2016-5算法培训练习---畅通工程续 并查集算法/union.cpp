#include<iostream>
using namespace std;

int N, M;
int parent[1002];

int pathNum = 0;

void Init()
{
	pathNum = 0;
	for (int i = 0; i < 1002; i++)
	{
		parent[i] = i;
	}
}

//���Ҹ��ڵ�,�ݹ�ʵ��
int root(int node)
{
	if (parent[node] != node)
	{
		return root(parent[node]);
	}
	else
	{
		return node;
	}
}

//���Ҹ��ڵ㣬ѭ��ʵ��
int root2(int node)
{
	int pre = node;
	while (parent[node] != node)	
	{
		node = parent[node];
	}
	return node;
}

int UnionSearch(int node1, int node2)
{
	int r1 = root(node1);
	int r2 = root(node2);

	if (r1 != r2)
	{
		parent[node2] = node1;
		pathNum++;
		return 1;
	}
	else
	{
		return 0;
	}
}

int main()
{
	//	freopen("input_ZOJ1709.txt", "r", stdin);
	setbuf(stdout, NULL);
	int T = 0;
	cin >> T;
	for (int testcase = 1; testcase <= T; testcase++)
	{		
		Init();
		cin >> N >> M;		
		for (int j = 1; j <= M; j++)
		{
			int node1, node2;
			cin >> node1 >> node2;
			UnionSearch(node1,node2);
		}

		int leftpath = N - 1 - pathNum;
		cout << leftpath << endl;
	}

	return 0;
}