#include<iostream>
#include<algorithm>
using namespace std;

int N, M;
int map[202][202];
int startnode, endnode;

typedef struct _NodeInfo
{
	int stnode;	
	int distance;
	int visited;
}NodeInfo;

NodeInfo DisMap[1002];
NodeInfo queue[202*202];




void Init()
{

	for (int i = 0; i < 202;i++)
	{
		for (int j = 0; j < 202;j++)
		{
			map[i][j] = 10002;
		}
	}

	for (int i = 0; i < 202; i++)
	{
		DisMap[i].distance = 10002;
		DisMap[i].stnode = i;	
		DisMap[i].visited = 0;
	}

	for (int i = 0; i < 202*202; i++)
	{
		queue[i].stnode = 0;
		queue[i].distance = 0;
		queue[i].visited = 0;
	}
}

int InsertQueue(NodeInfo item, int index)
{	
	int i = 0;
	for (i = 0; i < index;i++)
	{
		if (item.distance >= queue[i].distance)
		{
			break;
		}
	}

	for (int j = index-1; j >= i;j--)
	{
		queue[j+1] = queue[j];
	}
	queue[i] = item;

	return ++index;
}

void Dijsktra(int start)
{
	int cur = 0;
	NodeInfo first;
	NodeInfo tmp_node;
	NodeInfo next_node;

	first.stnode = start;
	first.distance = 0;
	first.visited = 0;
	queue[cur++] = first;
	DisMap[1] = first;


	while (cur != 0)
	{
		tmp_node = queue[--cur];
		if (DisMap[tmp_node.stnode].visited == 1) continue;
		DisMap[tmp_node.stnode].visited = 1;

		for (int i = 1; i <= N;i++)
		{
			if (map[tmp_node.stnode][i] >= 10000) continue;
			if (DisMap[i].visited == 1) continue;
			if (DisMap[i].distance > DisMap[tmp_node.stnode].distance + map[tmp_node.stnode][i])
			{
				DisMap[i].distance = DisMap[tmp_node.stnode].distance + map[tmp_node.stnode][i];				
				next_node.stnode = i;
				next_node.distance = DisMap[i].distance;
				cur = InsertQueue(next_node, cur);
			}
		}
	}
}

int main()
{
	//	freopen("input_ZOJ1709.txt", "r", stdin);
	setbuf(stdout, NULL);
	int T = 0;
	cin >> T;
	for (int testcase = 1; testcase <= T; testcase++)
	{
		Init();
		cin >> N >> M;
		for (int i = 1; i <= M;i++)
		{
			int node1, node2,distance;
			cin >> node1 >> node2 >> distance;
			map[node1 + 1][node2 + 1] = map[node2 + 1][node1 + 1] = distance;
		}

		cin >> startnode >> endnode;

		Dijsktra(startnode+1);

		if (DisMap[endnode + 1].distance >= 10000)
		{
			cout << -1 << endl;
		}
		else
		{
			cout << DisMap[endnode + 1].distance << endl;
		}		

	}

	return 0;
}