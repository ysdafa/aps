#include<iostream>
#include<algorithm>
using namespace std;

int map[152][152];
int N; //Total bus numbers

typedef struct _EdgeInfo
{
	int id;
	int id_next;
	char nodestr[32];
	char nextnodestr[32];
	int time;
};

struct _EdgeInfo  EdgeInfo[10002];

char startpoint[32];
char endpoint[32];
int endpointindex;

int Nodesize = 0;

//Dijsktra �㷨˼�룺
//data struct definition
typedef struct _NodeInfo
{
	int id;		
	int visited;
	int distance;
};
struct _NodeInfo  NodeInfo[152];
struct _NodeInfo queue[152 * 152];



void init()
{
	for (int i = 0; i < 10002; i++)
	{		
		EdgeInfo[i].id = 0;
		EdgeInfo[i].id_next = 0;
		EdgeInfo[i].time = 0;		
		for (int k = 0; k < 32; k++)
		{
			EdgeInfo[i].nodestr[k] = 0;
			EdgeInfo[i].nextnodestr[k] = 0;
		}
	}

	for (int i = 0; i < 152; i++)
	{
		for (int j = 0; j < 152; j++)
		{
			map[i][j] = 105;
		}		
		NodeInfo[i].id = 0;		
		NodeInfo[i].visited = 0;
		NodeInfo[i].distance = 105;				
	}	

	for (int i = 0; i < 152 * 152; i++)
	{
		queue[i].id = 0;
		queue[i].distance = 0;
		queue[i].visited = 0;
	}

	for (int i = 0; i < 32; i++)
	{
		startpoint[i] = 0;
		endpoint[i] = 0;
	}

	endpointindex = -1;
	Nodesize = 0;
}

int FindIndex(char nodestr[], int node)
{
	int i = 0, j = 0;
	for (j = 1; j < node; j++)
	{
		for (i = 0; i < strlen(nodestr); i++)
		{
			if (nodestr[i] != EdgeInfo[j].nodestr[i])
			{
				break;
			}			
		}

		if (i >= strlen(nodestr)) return EdgeInfo[j].id;

		for (i = 0; i < strlen(nodestr); i++)
		{
			if (nodestr[i] != EdgeInfo[j].nextnodestr[i])
			{
				break;
			}
		}

		if (i >= strlen(nodestr)) return EdgeInfo[j].id_next;
	}	

	return ++Nodesize;
}

int InsertQueue(struct _NodeInfo item, int cur)
{
	int curindex;
	int i = 0,j = 0;
	for (i = 0; i < cur;i++)
	{
		if (item.distance >= queue[i].distance)
		{
			break;
		}
	}

	for (j = cur-1; j >= i; j--)
	{
		queue[j+1] = queue[j];
	}

	queue[i] = item;

	return ++cur;
}

int Dijsktra()
{	
	int cur = 0;
	struct _NodeInfo tmp_node;
	struct _NodeInfo node;
	node.id = 1;
	node.visited = 0;
	node.distance = 0;
	NodeInfo[1] = node;
		
	queue[cur++] = node;

	while (cur != 0)
	{
		tmp_node = queue[--cur];
		if (tmp_node.visited != 0) continue;
		tmp_node.visited = 1;
		for (int i = 1; i <= 152;i++)
		{
			if (map[tmp_node.id][i] >= 100) continue;		
			if (NodeInfo[i].visited != 0) continue;
			if (NodeInfo[i].distance > NodeInfo[tmp_node.id].distance + map[tmp_node.id][i])
			{
				NodeInfo[i].distance = NodeInfo[tmp_node.id].distance + map[tmp_node.id][i];
				NodeInfo[i].id = i;
				cur = InsertQueue(NodeInfo[i], cur);
			}
		}
	}

	return 1;
}


int main()
{	
	//	freopen("input_ZOJ1709.txt", "r", stdin);
	setbuf(stdout, NULL);
	
	cin >> N;
	do
	{
		init();
		cin >> startpoint;
		cin >> endpoint;
		for (int node = 1; node <= N; node++)
		{			
			cin >> EdgeInfo[node].nodestr;
			cin >> EdgeInfo[node].nextnodestr;
			cin >> EdgeInfo[node].time;
		}

		EdgeInfo[1].id = 1;
		EdgeInfo[1].id_next = 2;
		Nodesize = 2;
		map[EdgeInfo[1].id][EdgeInfo[1].id_next] = EdgeInfo[1].time;
		for (int edge = 2; edge <= N; edge++)
		{
			int index = FindIndex(EdgeInfo[edge].nodestr, edge);
			EdgeInfo[edge].id = index;

			index = FindIndex(EdgeInfo[edge].nextnodestr, edge);
			EdgeInfo[edge].id_next = index;

			map[EdgeInfo[edge].id][EdgeInfo[edge].id_next] = EdgeInfo[edge].time;
		}

		endpointindex = FindIndex(endpoint, N);

		Dijsktra();

		int result = NodeInfo[endpointindex].distance;
		cout << result << endl;

		cin >> N;
	} while (N != -1);
	
	return 0;
}
